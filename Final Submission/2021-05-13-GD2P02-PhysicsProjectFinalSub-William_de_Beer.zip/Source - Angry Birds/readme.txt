Mad Birds - William de Beer

Controls:
- Left click highlighted bird and pull back to charge bird, release to launch.
- Press Q to go back to the main menu.

Birds:
- Basic bird: It does basic things.
- Spin bird: After a short delay the bird will start spinning backwards very fast.
- Tire bird: After being launched the bird will inflate. Once fully inflated, the bird will be heavier and bouncier.
- Que bird: After a short delay the bird will change into a square, get heavier, launch forwards and downwards.
